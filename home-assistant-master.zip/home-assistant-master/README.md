# home-assistant

Some assistance to deal with home maintenance

## Usage

Clone this repo:

  `git clone https://github.com/edupo/home-assistant.git`

Execute the install and configuration targets:

  ```
  cd home-assistant
  make install all
  make config all
  ```

## What will happen?

These makefiles installs `vim`, `tmux` and configures `bash_aliases` and the
installed tools.
Is a basic bootstrap that for my personal needs.
